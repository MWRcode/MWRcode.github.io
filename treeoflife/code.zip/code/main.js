import { math } from './math.js';
import { spatialGrid } from './spatialGrid.js';
import { renderManager } from './renderManager.js';

const canvas = document.getElementById("mainCanvas");
const ctx = canvas.getContext("2d");

// const svg = document.getElementById("svg");

canvas.style.background = "#222";

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

const grid = new spatialGrid([50, 50]);

const renderer = new renderManager([1000, 1000]);

let nodes = new Set();

let circleCount = 0;

let camera = { x: 0, y: 0, zoom: 1 };

let mouseStartPos = { x: null, y: null };

let isUpdating = false;

// Variables
let maxAge = 8;
let simSpeed = 1;
let minDistance = 20;
let maxProduce = 2;
let spawnRange = [-40, 40, -40, -8]; //[-40, 40, -40, -8]
let mutation = 0.04;

document.getElementById("reset").onclick = reset;
document.getElementById("play").onclick = play;
document.getElementById("forward").onclick = () => { update(1000); };

window.addEventListener("resize", () => {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
});

canvas.addEventListener("mousedown", (event) => {
  mouseStartPos.x = event.clientX;
  mouseStartPos.y = event.clientY;
});

window.addEventListener("mousemove", (event) => {
  if (mouseStartPos.x != null) {
    camera.x += (mouseStartPos.x - event.clientX) * (1 / camera.zoom);
    camera.y += (mouseStartPos.y - event.clientY) * (1 / camera.zoom);
    mouseStartPos.x = event.clientX;
    mouseStartPos.y = event.clientY;
  }
});

window.addEventListener("mouseup", (event) => {
  if (mouseStartPos.x != null) {
    camera.x += (mouseStartPos.x - event.clientX) * (1 / camera.zoom);
    camera.y += (mouseStartPos.y - event.clientY) * (1 / camera.zoom);
    mouseStartPos.x = null;
    mouseStartPos.y = null;
  }
});

canvas.addEventListener("touchstart", (event) => {
  mouseStartPos.x = event.changedTouches[0].clientX;
  mouseStartPos.y = event.changedTouches[0].clientY;
});

window.addEventListener("touchmove", (event) => {
  if (mouseStartPos.x != null) {
    camera.x += (mouseStartPos.x - event.changedTouches[0].clientX) * (1 / camera.zoom);
    camera.y += (mouseStartPos.y - event.changedTouches[0].clientY) * (1 / camera.zoom);
    mouseStartPos.x = event.changedTouches[0].clientX;
    mouseStartPos.y = event.changedTouches[0].clientY;
  }
});

window.addEventListener("touchend", (event) => {
  if (mouseStartPos.x != null) {
    camera.x += (mouseStartPos.x - event.changedTouches[0].clientX) * (1 / camera.zoom);
    camera.y += (mouseStartPos.y - event.changedTouches[0].clientY) * (1 / camera.zoom);
    mouseStartPos.x = null;
    mouseStartPos.y = null;
  }
});

window.addEventListener('mouseleave', (event) => {
  if (mouseStartPos.x != null) {
    camera.x += (mouseStartPos.x - event.clientX) * (1 / camera.zoom);
    camera.y += (mouseStartPos.y - event.clientY) * (1 / camera.zoom);
    mouseStartPos.x = null;
    mouseStartPos.y = null;
  }
});

canvas.addEventListener('wheel', (event) => {
  camera.zoom *= 1 + event.deltaY * -0.001;
  camera.zoom = Math.max(camera.zoom, 0.0001);
});

function veiwTransform(xpos, ypos) {
  return [(xpos - camera.x - canvas.width / 2) * camera.zoom + canvas.width / 2, (ypos - camera.y - canvas.height / 2) * camera.zoom + canvas.height / 2];
}

function createNode(xpos, ypos, pxpos, pypos, color) {
  grid.newClient([xpos, ypos], [minDistance, minDistance]);
  const node = new Node(xpos, ypos, color);
  nodes.add(node);
  renderer.addNode(xpos, ypos, pxpos, pypos, hslToHex(color[0] * 360, 100, color[1] * 100), 5);

  // const circ = document.createElementNS("http://www.w3.org/2000/svg", "circle");
  // circ.setAttribute("r", 5);
  // circ.setAttribute("cx", xpos);
  // circ.setAttribute("cy", ypos);
  // circ.setAttribute("fill", hslToHex(color[0] * 360, 100, color[1] * 100));
  // svg.append(circ);

  // const line = document.createElementNS("http://www.w3.org/2000/svg", "line");
  // line.setAttribute("x1", xpos);
  // line.setAttribute("y1", ypos);
  // line.setAttribute("x2", pxpos);
  // line.setAttribute("y2", pypos);
  // line.setAttribute("stroke", "#555");
  // line.setAttribute("stroke-width", 2);
  // svg.prepend(line);

  circleCount++;
}

function hslToHex(h, s, l) {
  s /= 100;
  l /= 100;

  const k = n => (n + h / 30) % 12;
  const a = s * Math.min(l, 1 - l);
  const f = n => Math.round(255 * (l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)))));

  const r = f(0);
  const g = f(8);
  const b = f(4);

  const toHex = x => x.toString(16).padStart(2, '0');
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}

function reset() {
  nodes = new Set();
  grid.removeAll();
  renderer.removeAll();

  circleCount = 0;

  createNode(canvas.width / 2, canvas.height / 2, canvas.width / 2, canvas.height / 2, [Math.random(), Math.random()]);
  camera = { x: 0, y: 0, zoom: 1 };
  pause();
}

function play() {
  const button = document.getElementById("play");
  isUpdating = true;
  button.style.backgroundImage = "url(/assets/pause.svg)";
  button.onclick = pause;
}

function pause() {
  const button = document.getElementById("play");
  isUpdating = false;
  button.style.backgroundImage = "url(/assets/play.svg)";
  button.onclick = play;
}

function setupSliders() {
  const sliderVars = [
    "simSpeed",
    "maxProduce",
    "minDistance",
    "maxAge",
    "mutation",
  ];
  sliderVars.forEach((sliderVar) => {
    const element = document.getElementById(sliderVar);
    document.getElementById(sliderVar + "Var").innerText = element.value;
    element.style.setProperty('--value', math.map(element.value, element.min, element.max) * 100 + "%");
  });
}
setupSliders();

document.getElementById("simSpeed").addEventListener("input", event => {
  simSpeed = event.target.value;
  document.getElementById(event.target.id + "Var").innerText = event.target.value;
  event.target.style.setProperty('--value', math.map(event.target.value, event.target.min, event.target.max) * 100 + "%");
});

document.getElementById("maxProduce").addEventListener("input", event => {
  maxProduce = event.target.value;
  document.getElementById(event.target.id + "Var").innerText = event.target.value;
  event.target.style.setProperty('--value', math.map(event.target.value, event.target.min, event.target.max) * 100 + "%");
});

document.getElementById("minDistance").addEventListener("input", event => {
  minDistance = event.target.value;
  document.getElementById(event.target.id + "Var").innerText = event.target.value;
  event.target.style.setProperty('--value', math.map(event.target.value, event.target.min, event.target.max) * 100 + "%");
});

document.getElementById("maxAge").addEventListener("input", event => {
  maxAge = event.target.value;
  document.getElementById(event.target.id + "Var").innerText = event.target.value;
  event.target.style.setProperty('--value', math.map(event.target.value, event.target.min, event.target.max) * 100 + "%");
});

document.getElementById("mutation").addEventListener("input", event => {
  mutation = event.target.value;
  document.getElementById(event.target.id + "Var").innerText = event.target.value;
  event.target.style.setProperty('--value', math.map(event.target.value, event.target.min, event.target.max) * 100 + "%");
});

class Node {
  constructor(xpos, ypos, color) {
    this.xpos = xpos;
    this.ypos = ypos;
    // this.prevXpos = prevXpos;
    // this.prevYpos = prevYpos;
    // this.veiwPos = veiwTransform(this.xpos, this.ypos);
    // this.veiwPrevPos = veiwTransform(this.prevXpos, this.prevYpos);
    this.age = 0;
    this.produced = 0;
    this.dead = false;
    this.preColor = color;
    // this.rgbColor = hslToHex(this.preColor[0] * 360, 100, this.preColor[1] * 100);
    this.timer = math.randrange(-1000, 0);
  }
  update(deltaTime) {
    this.timer += deltaTime;
    this.age += deltaTime / 1000;

    while (this.timer > 1000 && !this.dead) {
      this.timer -= 1000;
      const xpos = this.xpos + math.randrange(spawnRange[0], spawnRange[1]);
      const ypos = this.ypos + math.randrange(spawnRange[2], spawnRange[3]);

      let finish = true;

      grid.findNear([xpos, ypos], [minDistance, minDistance]).forEach((node) => {
        if (math.getsqrdist(xpos, ypos, node.position[0], node.position[1]) < minDistance ** 2) {
          finish = false;
        }
      });

      if (finish) {
        const color = [
          math.clamp(this.preColor[0] + math.randrange(-mutation / 2, mutation / 2), 0, 1),
          math.clamp(this.preColor[1] + math.randrange(-mutation / 2, mutation / 2), 0, 1)
        ];
        createNode(xpos, ypos, this.xpos, this.ypos, color);
        this.produced++;
      }

      if (this.produced >= maxProduce) {
        this.dead = true;
      }
    }
    if (this.age >= maxAge && maxAge != 0) {
      this.dead = true;
    }
  }
  // drawSpawnRange() {
  //   ctx.fillStyle = "#EEEE11";
  //   ctx.fillRect(x + spawnRange[0], y + spawnRange[2], spawnRange[1] - spawnRange[0], spawnRange[3] - spawnRange[2]);
  // }
}

reset();

function update(deltaTime) {
  // Update nodes

  for (const node of nodes) {
    node.update(deltaTime);
    if (node.dead) {
      nodes.delete(node);
    }
  }

}

let lastTime = 0;
function loop(timeStamp) {
  let deltaTime = Math.min(timeStamp - lastTime, 100); // limit deltatime to 1/10 of a second to avoid lag
  lastTime = timeStamp;
  
  renderer.render(canvas, ctx, camera);

  console.log(circleCount);
  document.getElementById("pointsVar").innerText = circleCount;

  // svg.setAttribute("width", window.innerWidth);
  // svg.setAttribute("height", window.innerHeight);
  // const view = `${camera.x - ((canvas.width / 2) / camera.zoom) + (canvas.width / 2)} ${camera.y - ((canvas.height / 2) / camera.zoom) + (canvas.height / 2)} ${window.innerWidth / camera.zoom} ${window.innerHeight / camera.zoom}`;
  // svg.setAttribute("viewBox", view);

  if (isUpdating) {
    for (let i = 0; i < simSpeed; i++) {
      update(deltaTime);
    }
  }

  requestAnimationFrame(loop);
}

loop(0);